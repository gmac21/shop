package entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;



@Entity
public abstract class Customer extends User {


    String payMethod;
    int loyaltyPoints;
    String shipAddress1;
    String shipAddress2;



    public Customer( ) {

    }

    public Customer(  String payMethod, int loyaltyPoints, String shipAddress1, String shipAddress2) {
        super();


        this.payMethod = payMethod;
        this.loyaltyPoints = loyaltyPoints;
        this.shipAddress1 = shipAddress1;
        this.shipAddress2 = shipAddress2;
    }

}