// angular.module('HorseApp',[
//     'ui.router',
//     'HorseApp.LoginController',
//     'HorseApp.AlgorithmController'
// ]).config(function($stateProvider) {
//
//     $stateProvider
//         .state('login', {
//             url: "/account/login",
//             templateUrl: "resources/js/views/login.html",
//             controller: 'LoginController'
//         });
//
//     $stateProvider
//         .state('algorithm', {
//             url: "/account/algorithm",
//             templateUrl: "resources/js/views/algorithm.html",
//             controller: 'AlgorithmController'
//         });
// });
//
//
//
//
