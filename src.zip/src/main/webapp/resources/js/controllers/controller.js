/**
 * Created by marym on 08/03/2017.
 */
var app = angular.module('mainApp' , []);

app.controller('horse', function($scope, $http) {

    }

);
