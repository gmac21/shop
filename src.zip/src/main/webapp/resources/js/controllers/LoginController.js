angular.module('HorseApp.LoginController',[]).
    controller('LoginController', function ($scope) {
    $scope.name = "GARETH";


});