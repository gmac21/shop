/*package RestAPI;

import dao.*;
import entity.*;

import javax.ws.rs.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Path("/api")
public class UserAPI {


    private HorseDAO horseDAO = new HorseDAO();
    private UserDAO userDAO = new UserDAO();
    private ResultDAO resultDAO = new ResultDAO();
    private RaceProfileDAO raceProfileDAO = new RaceProfileDAO();
    private TrainerDAO trainerDAO = new TrainerDAO();
    private RaceDAO raceDAO = new RaceDAO();
    private FormDao formDao = new FormDao();






    @GET
    @Path(value="/getAllResult")
    @Produces(value={"application/json"})
    public List<Result> getAllResults() {

        List<Result> resultList = resultDAO.findAll();
       return resultList;
    }

    @GET
    @Path(value="/getAllHorses")
    @Produces(value={"application/json"})
    public List<Horse> getAllHorses() {

        List<Horse> horseList = horseDAO.findAll();
        return horseList;
    }

    @GET
    @Path(value="/getAllTrainers")
    @Produces(value={"application/xml"})
    public List<Trainer> getAllTrainers() {

        List<Trainer> trainerList = trainerDAO.findAll();
        return trainerList;
    }

    @GET
    @Path(value="/getAllRaces")
    @Produces(value={"application/json"})
    public List<Race> getAllRaces() {

        List<Race> raceList = raceDAO.findAll();
        return raceList;
    }

    @GET
    @Path(value="/getAllUsers")
    @Produces(value={"application/json"})
    public List<User> getAllUsers() {

        List<User> userList = userDAO.findAll();
        return userList;
    }

    @GET
    @Path(value="/getAllForm")
    @Produces(value={"application/json"})
    public List<Form> getAllForm() {

        List<Form> formList = formDao.findAll();
        return formList;
    }

    @GET
    @Path(value="/getAllProfile")
    @Produces(value={"application/json"})
    public List<RaceProfile> getAllProfile() {

        List<RaceProfile> rp = raceProfileDAO.findAll();
        return rp;
    }





    @GET
    @Path(value="/hello")
    @Produces(value={"application/json"})
    public String Hello(){
        return "Hello World";
    }




}
*/